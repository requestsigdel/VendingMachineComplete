package com.projects.vendingmachineapp.api.model;

public class Product {
    private String name;
    private double price;
    private int inventory;
    private int refundCount;
    private double refundAmount;

    public int getRefundCount() {
        return refundCount;
    }

    public void setRefundCount(int refundCount) {
        this.refundCount = refundCount;
    }

    public double getRefundAmount() {
        return refundAmount;
    }

    public void setRefundAmount(double refundAmount) {
        this.refundAmount = refundAmount;
    }

    public Product(){
    }
    public Product(String name, double price, int inventory, int refundCount, int refundAmount) {
        super();
        this.name = name;
        this.price = price;
        this.inventory = inventory;
        this.refundCount = refundCount;
        this.refundAmount = refundAmount;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getInventory() {
        return inventory;
    }

    public void setInventory(int inventory) {
        this.inventory = inventory;
    }
}
