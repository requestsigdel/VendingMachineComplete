package com.projects.vendingmachineapp.service;

import com.projects.vendingmachineapp.api.model.Product;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class ProductService {
    private List<Product> allProducts = new ArrayList<>(Arrays.asList(
            new Product("Soda", 0.95, 10, 0, 0),
            new Product("Candy Bar", 0.60, 10, 0, 0),
            new Product("Chips", 0.99, 10, 0,0)
    ));

    public List<Product> getAllProducts(){
        return allProducts;
    }

    public void updateProduct(String item, Product product){
        for (int i = 0; i < allProducts.size(); i++){
            Product pr = allProducts.get(i);
            if (pr.getName().equals(item)){
                // get the product inventory
                int remainingInventory = pr.getInventory() - product.getInventory();
                if (0 > remainingInventory) {
                    remainingInventory = 0;
                }
                pr.setInventory(remainingInventory);
                allProducts.set(i, pr);
            }
        }
    }

    public void refundProduct(String item, Product product){
        for (int i = 0; i < allProducts.size(); i++){
            Product pr = allProducts.get(i);
            if (pr.getName().equals(item)){
                // increase inventory since refund was asked
                int remainingInventory = pr.getInventory() + product.getInventory();

                if(remainingInventory > 10)
                    pr.setInventory(10);
                else{
                    pr.setInventory(remainingInventory);

                    // add refund amount and track of refund for this product
                    pr.setRefundCount(pr.getRefundCount()+1);
                    pr.setRefundAmount(product.getInventory() * product.getPrice() + pr.getRefundAmount());
                }

                allProducts.set(i, pr);
            }
        }
    }
}
